import axios from 'axios';

axios.defaults.headers.common['Accept'] = 'application/json';
axios.defaults.headers.common['Authorization'] = "bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2Mjc0YWEzZGQzYWMyZDFmNjg3MGQzZTQiLCJpZCI6IjYyNzRhYTNkZDNhYzJkMWY2ODcwZDNlNCIsImlhdCI6MTY1MTgxNDIzNCwiZXhwIjoxNjUxODE1MTM0fQ.a48YottbGKxkQFHhp6xCEu2z12DnZtanKoWYToJzqyg"