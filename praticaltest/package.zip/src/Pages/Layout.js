import React from 'react'


function Layout() {
  return (
    <div>
     <h1>layout</h1>
    </div>
  )
}

export default Layout