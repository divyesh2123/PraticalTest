import React from 'react'
// import Admin from './Admin'
// import API from './API'
import Header from './Header'
// import Login from './Login'
import { ReactDOM } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Pages/Layout";
import Home from "./Pages/Home";
import Blogs from "./Pages/Blogs";
import Contact from "./Pages/Contact";
import NoPage from "./Pages/NoPage";
import Login from './Login'


import Registration from './Pages/Registration';

function App() {
  return (
   <>
     {/* <Registration></Registration> */}
     {/* <Admin></Admin> */}
     {/* <Login></Login> */}
     {/* <SignIn></SignIn> */}
     {/* <API></API> */}
     {/* <Header></Header> */}
     <BrowserRouter>
     <Routes>
          <Route  path="/" element={<Header/>}/>
          <Route   element={<Home />} />
          <Route path="/blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NoPage />} />
          <Route path="/login" element= {<Login/>}/>
          <Route path="/Registration" element= {<Registration/>}/>
      </Routes>
      </BrowserRouter>
   </>
  )
}

export default App 